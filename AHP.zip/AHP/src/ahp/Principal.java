package ahp;

import java.util.*;

/**
 *
 * @author Browndon
 */
public class Principal {
    public static void main(String[] args) {
        ArrayList liste = new ArrayList();
        int i, n, j, n2, reco;
        AHP ahp = new AHP();
        Scanner keyboard=new Scanner(System.in);
        do{
            System.out.print("Enter the number of criteria : ");
            n=keyboard.nextInt();
            double [][] comp = new double[n][n]; //table for the pair comparison
            String [] criteres = new String[n]; //table for criteria
            int [] criteresComp = new int[n]; //table for sens of comparison to the criteria
            System.out.println("\nEnter the name of criteria (maximum 3 letters) : ");
            for(i=0; i<n;i++){
                System.out.print("\tCriteria "+(i+1)+" : ");
                criteres[i] = keyboard.next();
                System.out.print("\t\tSens of comparison (0 for minimum and 1 for maximum) : ");
                criteresComp[i] = keyboard.nextInt();
            }
            //The comparison number filled is (n*n-n)/2; the rest are calculate
            System.out.println("\nEnter the pair comparison : ");
            for(i=0; i<n;i++) {
                for(j=0; j<n;j++) {
                    if(i==j) comp[i][j] = 1;
                    else if(j>i){
                        System.out.print("\tBetween "+criteres[i]+" and "+criteres[j]+" : ");
                        comp[i][j] = keyboard.nextDouble();
                        comp[j][i] = 1 / comp[i][j];
                    }
                }
            }
            liste = ahp.AHP_CR_Weight(criteres, criteresComp, comp);
            if((double)liste.get(1) <= 0.1){
                System.out.println("\nEvaluation is coherent. Let us continue.\n");
                //Prioritization of criteria
                liste = ahp.ReorganizeCriteria(criteres, (double [])liste.get(0), criteresComp);
                System.out.println("The criteria in oder of priority are : ");
                criteres = (String [])liste.get(0);
                criteresComp = (int [])liste.get(1);
                for(i = 0; i < n; i++){
                    System.out.println("\t"+(i+1)+"- "+criteres[i]+"\t : "+criteresComp[i]);
                }
                //Define the values of criteria for the individuals or objects 
                do{
                    System.out.print("\nNumber of individuals or objects : ");
                    n2=keyboard.nextInt();
                    double [][] criteresPers = new double[n2][n];
                    System.out.println("\nEnter the values of criteria : ");
                    for(i=0; i<n2; i++) {
                        System.out.print("\tIndividual / Object "+(i+1)+" : \n");
                        for(j=0; j<n; j++) {
                            System.out.print("\t\t"+criteres[j]+" : ");
                            criteresPers[i][j] = keyboard.nextDouble();
                        }
                    }
                    liste = ahp.ResultAhp(criteresPers, criteresComp);
                    System.out.print("\nResult by number of individuals / objects : ");
                    for (int k = 0; k < liste.size(); k++) {
                        System.out.print(" "+((int)liste.get(k)+1)+" - ");
                    }
                    System.out.print("\n\nDo you ave another individuals / objetcs to analyse ? (1 for yes or 0 for no) : ");
                    reco = keyboard.nextInt();
                }while(reco == 1);
            }
            else  System.out.println("\nEvalution is not coherent. Verify your values.\n");
            System.out.print("\nDo you want to test another criteria ? (1 for yes or 0 for no) : ");
            reco = keyboard.nextInt();
        }while(reco == 1);
   }
}