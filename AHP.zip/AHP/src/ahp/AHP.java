package ahp;

import java.util.*;

/**
 *
 * @author Browndon
 */
public class AHP {
    // Calculate the CR (consistence ratio) and the weight to prioritize the criteria
    ArrayList AHP_CR_Weight (String [] criteres, int [] criteresComp, double [][] comp){
        int i, n = criteres.length, j;
        double lamdaMax = 0, CI, CR; // CR is consistent ratio
        double [][] comp1 = new double [n][n]; // comp1 is a copy of the matrix which content the pair comparaison
        for(i=0; i<n; i++) for(j=0; j<n; j++) comp1[i][j] = comp[i][j];
        double [] sum = new double[n], wei = new double[n], weiSum = new double[n], ratio = new double[n];
        double [] randomIndex = {0,0,0.58,0.9,1.12,1.24,1.32,1.41,1.45,1.49};
        ArrayList resultat = new ArrayList();
        //Display of the starting matrix
        System.out.println("\nThe starting matrix is : ");
        for(i=0; i<n; i++) System.out.print("\t"+criteres[i]);
        System.out.println("");
        for(i=0; i<n;i++) {
            System.out.print(criteres[i]);
            for(j=0; j<n;j++) System.out.print("\t"+((double)((int)(comp[i][j]*1000))/1000));
            System.out.println("");
        }
        //We associate to the matrix the sum of the values of each column
        for(j=0;j<n;j++) for(i=0;i<n;i++) sum[j] = sum[j] + comp[i][j];
        //We divide each element of the matrix by the sum of the elements of its column
        //Display of the normalize matrix
        System.out.println("\nThe normalize matrix is : ");
        for(i=0; i<n; i++) System.out.print("\t"+criteres[i]);
        System.out.println("");
        for(i=0; i<n;i++) {
            System.out.print(criteres[i]);
            for(j=0; j<n;j++){
                comp[i][j] = comp[i][j] / sum[j];
                System.out.print("\t"+((double)((int)(comp[i][j]*1000))/1000));
            }
            System.out.println("");
        }
        //We calculate the weight criteria which is the avarage of the values of each row
        for(i=0;i<n;i++){
            for(j=0;j<n;j++) wei[i] = wei[i] + comp[i][j];
            wei[i] = wei[i] / n;
        }
        //Display of the matrix with the weight criteria
        System.out.println("\nThe matrix with the weight criteria is : ");
        for(i=0; i<n; i++) System.out.print("\t"+criteres[i]);
        System.out.print("\tWeight\n");
        for(i=0; i<n;i++) {
            System.out.print(criteres[i]);
            for(j=0; j<n;j++){
                System.out.print("\t"+((double)((int)(comp[i][j]*1000))/1000));
            }
            System.out.print("\t"+((double)((int)(wei[i]*1000))/1000)+"\n");
        }
        //verification of the consistency of the matrix
        System.out.println("\nThe matrix for the verification of consistency is : ");
        for(i=0; i<n; i++) System.out.print("\t"+criteres[i]);
        System.out.print("\tW.Sum");
        System.out.print("\tRatio\n");
        for (i = 0; i < n; i++) {
                System.out.print(criteres[i]);
            for (j = 0; j < n; j++) {
                comp1[i][j] = comp1[i][j] * wei[j];
                weiSum[i] = weiSum[i] + comp1[i][j];
                System.out.print("\t"+((double)((int)(comp1[i][j]*1000))/1000));
            }
            ratio[i] = weiSum[i] / wei[i];
            lamdaMax = lamdaMax + ratio[i];
            System.out.print("\t"+((double)((int)(weiSum[i]*1000))/1000));
            System.out.print("\t"+((double)((int)(ratio[i]*1000))/1000)+"\n");
        }
        lamdaMax = lamdaMax / n;
        System.out.print("\nLamdaMax = "+((double)((int)(lamdaMax*1000))/1000));
        CI = (lamdaMax - n) / (n - 1);
        System.out.print("\t CI = "+((double)((int)(CI*1000))/1000));
        CR = CI / randomIndex[n-1];
        System.out.println("\t Consistence Ratio = "+((double)((int)(CR*1000))/1000));
        resultat.add(wei);
        resultat.add(CR);
        return resultat;
    }
    
    //Reorganize the criteria with the sens of critera comparison based on the weight
    ArrayList ReorganizeCriteria(String [] criteres, double [] wei, int [] criteresComp){
        int i, j, index, n = criteres.length;
        ArrayList resultat = new ArrayList(); //
        for(i = 0; i < n; i++){
            index = i;
            for(j = i + 1; j < n ; j++){
                if(wei[j] > wei[index]){
                    index = j;
                }
            }
            double max = wei[index]; String maxCr = criteres[index]; int maxCrComp = criteresComp[index];
            wei[index] = wei[i]; criteres[index] = criteres[i]; criteresComp[index] = criteresComp[i];
            wei[i] = max; criteres[i] = maxCr; criteresComp[i] = maxCrComp;
        }
        resultat.add(criteres);
        resultat.add(criteresComp);
        return resultat;
    }
    
    //Determine the best solution to AHP with the criteria value of individuals or object
    ArrayList ResultAhp(double[][] criteresPers, int [] criteresComp){
        ArrayList liste = new ArrayList();
        int i = 0, n = criteresComp.length, n2 = criteresPers.length, trouve = 0, j;
        double MinMax;
        if(criteresComp[i]==0) MinMax = minimum(criteresPers, i, n2);
        else MinMax = maximum(criteresPers, i, n2);
        for (j = 0;  j < n2; j++) {
            if(criteresPers[j][i] == MinMax){
                liste.add(j);
            }
        }
        if(liste.size() == 1) trouve = 1;
        i = i + 1;
        while(i < n && trouve == 0){
            if(criteresComp[i]==0) MinMax = minimum(criteresPers, i, n2);
            else MinMax = maximum(criteresPers, i, n2);
            for (int k = 0; k < liste.size(); k++) {
                if(criteresPers[(int)liste.get(k)][i] != MinMax){
                    liste.remove(liste.get(k));
                }
            }
            i = i + 1;
            if(liste.size() == 1) trouve = 1;
        }
        return liste;
        //the lis to return can have more than one element if these elements are identically the same criteria
    }
    
    double minimum(double [][]tab, int colonne, int nbreLigne){
       double temp = tab[0][colonne];
       for (int i = 1; i < nbreLigne; i++) {
           if(tab[i][colonne]<temp) temp = tab[i][colonne];
       }
       return temp;
    }
   
    double maximum(double [][] tab, int colonne, int nbreLigne){
       double temp = tab[0][colonne];
       for (int i = 1; i < nbreLigne; i++) {
           if(tab[i][colonne]>temp) temp = tab[i][colonne];
       }
       return temp;
    }
}